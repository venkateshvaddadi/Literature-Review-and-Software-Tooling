The following are the folders in the question_03 section:

------------------------------------------------------------
dataset:
--------------------------------------------------------------
Its a dataset of the ayush doctors .
It has the statastics about ayush doctors in various states.

we can download from the following link:

https://data.gov.in/resources/stateut-wise-ayush-doctors-community-health-centres-rural-areas-31st-march-2019

The following is the name of the dataset file in the folder:

RHS-2019-Section-V-Status-of-Health-Manpower-in-Rural-areas-Table-21.csv


----------------------------------------------------------------------------
plots:
---------------------------------------------------------------
We can see the plots folder it consisting of scatter plot,bar plot and box plots of above dataset.
which are outputs of the  question_03_scripts.ipynb file. 

------------------------------------------------------------------
about scripts files:
---------------------------------------------------------------------
scitp: question_03_scripts.ipynb is used to draw the above specified plots.
it reads the above mentioned dataset from csv fomat.
we plotted all the plots.
It can be open in jupytor notebook.

-----------------------------------
Report:
--------------------------------
Question_03.pdf  is the report for the Question3.
